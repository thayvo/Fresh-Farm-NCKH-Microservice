﻿SET NOCOUNT ON;
GO

IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    RAISERROR(N'Products chua ton tai. Hay apply schema Catalog truoc.', 16, 1);
    RETURN;
END;
GO

IF OBJECT_ID(N'dbo.ProductSeasonality', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ProductSeasonality
    (
        ProductSeasonalityID int IDENTITY(1,1) NOT NULL,
        ProductID int NOT NULL,
        Country nvarchar(80) NULL,
        ProvinceRegion nvarchar(200) NULL,
        AreaDetail nvarchar(200) NULL,
        SeasonType nvarchar(60) NOT NULL,
        SeasonLabel nvarchar(180) NOT NULL,
        StartMonth tinyint NOT NULL,
        EndMonth tinyint NOT NULL,
        PeakMonths nvarchar(80) NULL,
        IsYearRound bit NOT NULL CONSTRAINT DF_ProductSeasonality_IsYearRound DEFAULT (0),
        HasPeakSeason bit NOT NULL CONSTRAINT DF_ProductSeasonality_HasPeakSeason DEFAULT (0),
        IsControlledCultivation bit NOT NULL CONSTRAINT DF_ProductSeasonality_IsControlledCultivation DEFAULT (0),
        IsImportedSeason bit NOT NULL CONSTRAINT DF_ProductSeasonality_IsImportedSeason DEFAULT (0),
        IsOffSeason bit NOT NULL CONSTRAINT DF_ProductSeasonality_IsOffSeason DEFAULT (0),
        IsPostHarvestAvailability bit NOT NULL CONSTRAINT DF_ProductSeasonality_IsPostHarvestAvailability DEFAULT (0),
        SeasonScoreWeight int NOT NULL CONSTRAINT DF_ProductSeasonality_SeasonScoreWeight DEFAULT (50),
        ConfidenceLevel nvarchar(40) NULL,
        SourceNote nvarchar(600) NULL,
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_ProductSeasonality_CreatedAt DEFAULT (SYSUTCDATETIME()),
        UpdatedAt datetime2(0) NOT NULL CONSTRAINT DF_ProductSeasonality_UpdatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT PK_ProductSeasonality PRIMARY KEY CLUSTERED (ProductSeasonalityID),
        CONSTRAINT FK_ProductSeasonality_Products_ProductID FOREIGN KEY (ProductID)
            REFERENCES dbo.Products(ProductID),
        CONSTRAINT CK_ProductSeasonality_StartMonth CHECK (StartMonth BETWEEN 1 AND 12),
        CONSTRAINT CK_ProductSeasonality_EndMonth CHECK (EndMonth BETWEEN 1 AND 12),
        CONSTRAINT CK_ProductSeasonality_SeasonScoreWeight CHECK (SeasonScoreWeight BETWEEN 0 AND 100)
    );

    CREATE UNIQUE INDEX UX_ProductSeasonality_Product_Season
        ON dbo.ProductSeasonality(ProductID, SeasonLabel, StartMonth, EndMonth);

    CREATE INDEX IX_ProductSeasonality_ProductID
        ON dbo.ProductSeasonality(ProductID);

    CREATE INDEX IX_ProductSeasonality_MonthWindow
        ON dbo.ProductSeasonality(StartMonth, EndMonth, IsYearRound, HasPeakSeason)
        INCLUDE (ProductID, SeasonType, SeasonLabel, PeakMonths, IsOffSeason);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'HasPeakSeason') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD HasPeakSeason bit NOT NULL
            CONSTRAINT DF_ProductSeasonality_HasPeakSeason DEFAULT (0);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'IsControlledCultivation') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD IsControlledCultivation bit NOT NULL
            CONSTRAINT DF_ProductSeasonality_IsControlledCultivation DEFAULT (0);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'IsImportedSeason') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD IsImportedSeason bit NOT NULL
            CONSTRAINT DF_ProductSeasonality_IsImportedSeason DEFAULT (0);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'IsOffSeason') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD IsOffSeason bit NOT NULL
            CONSTRAINT DF_ProductSeasonality_IsOffSeason DEFAULT (0);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'IsPostHarvestAvailability') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD IsPostHarvestAvailability bit NOT NULL
            CONSTRAINT DF_ProductSeasonality_IsPostHarvestAvailability DEFAULT (0);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'SeasonScoreWeight') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD SeasonScoreWeight int NOT NULL
            CONSTRAINT DF_ProductSeasonality_SeasonScoreWeight DEFAULT (50);
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'ConfidenceLevel') IS NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality
        ADD ConfidenceLevel nvarchar(40) NULL;
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'ProductName') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality DROP COLUMN ProductName;
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'CategoryName') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality DROP COLUMN CategoryName;
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'DbRuleHint') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality DROP COLUMN DbRuleHint;
END;
GO

IF COL_LENGTH(N'dbo.ProductSeasonality', N'ReviewNote') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ProductSeasonality DROP COLUMN ReviewNote;
END;
GO

;WITH SourceRows
(
    ProductID,
    Country,
    ProvinceRegion,
    AreaDetail,
    SeasonType,
    SeasonLabel,
    StartMonth,
    EndMonth,
    PeakMonths,
    IsYearRound,
    HasPeakSeason,
    IsControlledCultivation,
    IsImportedSeason,
    IsOffSeason,
    IsPostHarvestAvailability,
    SeasonScoreWeight,
    ConfidenceLevel,
    SourceNote
)
AS
(
    SELECT *
    FROM
    (
        VALUES
        (1, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Rau muống vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (2, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Cải bó xôi mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (2, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Cải bó xôi rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (3, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Rau lang vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (4, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Cải thìa mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (4, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Cải thìa rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (5, N'Việt Nam', N'Đồng Nai', NULL, N'Quanh năm', N'Rau dền đỏ vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (6, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Bông cải xanh mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (6, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Bông cải xanh rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (7, N'Việt Nam', N'Bình Thuận', NULL, N'Vụ chính', N'Súp lơ trắng mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (7, N'Việt Nam', N'Bình Thuận', NULL, N'Vụ phụ', N'Súp lơ trắng rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (8, N'Việt Nam', N'Ninh Thuận', NULL, N'Vụ chính', N'Măng tây Ninh Thuận mùa nắng', 2, 8, N'3-7', 0, 0, 0, 0, 0, 0, 100, NULL, N'Măng tây vùng khô nóng có thể thu nhiều lứa, thuận mùa nắng.'),
        (9, N'Việt Nam', N'Cần Thơ', NULL, N'Quanh năm', N'Rau mầm hướng dương - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (10, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Cà chua bi Đà Lạt', 1, 12, N'11-4', 1, 1, 0, 0, 0, 0, 80, NULL, N'Cà chua Đà Lạt có thể sản xuất quanh năm, thuận mùa mát.'),
        (11, N'Việt Nam', N'Bến Tre', NULL, N'Quanh năm', N'Dưa leo Bến Tre', 1, 12, N'11-4', 1, 1, 0, 0, 0, 0, 80, NULL, N'Dưa leo miền Nam có thể trồng nhiều vụ/năm.'),
        (12, N'Việt Nam', N'Bình Dương', NULL, N'Quanh năm', N'Bí đỏ vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (13, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Cà rốt mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (13, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Cà rốt rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (14, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Khoai tây vàng mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (14, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Khoai tây vàng rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (15, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Rau cải ngọt mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (15, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Rau cải ngọt rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (16, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Cải ngồng mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (16, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Cải ngồng rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (17, N'Việt Nam', N'Đồng Nai', NULL, N'Quanh năm', N'Rau diếp cá vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (18, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Rau má vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (19, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Cải xoăn kale mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (19, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Cải xoăn kale rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (20, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Bông cải trắng mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (20, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Bông cải trắng rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (21, N'Việt Nam', N'TP.HCM', NULL, N'Quanh năm', N'Rau mầm đậu Hà Lan - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (22, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Hoa thiên lý mùa nóng/mưa', 4, 10, N'5-8', 0, 0, 0, 0, 0, 0, 100, NULL, N'Hoa thiên lý thường rộ khi thời tiết ấm.'),
        (23, N'Việt Nam', N'Bình Thuận', NULL, N'Quanh năm', N'Cà tím vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (24, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Đậu cove vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (25, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Ớt chuông Đà Lạt', 1, 12, N'11-4', 1, 1, 0, 0, 0, 0, 80, NULL, N'Ớt chuông nhà kính/Đà Lạt có thể cung ứng quanh năm.'),
        (26, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Củ dền mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (26, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Củ dền rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (27, N'Việt Nam', N'Bình Dương', NULL, N'Vụ chính', N'Khoai lang tím Đông Xuân', 12, 4, N'2-4', 0, 0, 0, 0, 0, 0, 100, NULL, N'Khoai lang thường có vụ Đông Xuân ở miền Nam.'),
        (28, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Nấm đùi gà - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (29, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Nấm mỡ - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (30, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Xà lách xoăn mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (30, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Xà lách xoăn rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (31, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Rau mồng tơi vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (32, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Cải chíp mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (32, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Cải chíp rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (33, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Rau spinach baby mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (33, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Rau spinach baby rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (34, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Rau húng quế vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (35, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Atiso Đà Lạt mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Atiso Đà Lạt thuận mùa mát.'),
        (36, N'Việt Nam', N'Nghệ An', NULL, N'Vụ chính', N'Măng tre mùa mưa', 5, 10, N'6-8', 0, 0, 0, 0, 0, 0, 100, NULL, N'Măng tre thường rộ mùa mưa.'),
        (37, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Bắp cải tím mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (37, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Bắp cải tím rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (38, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Cải Brussels sprouts mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (38, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Cải Brussels sprouts rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (39, N'Việt Nam', N'TP.HCM', NULL, N'Quanh năm', N'Rau mầm alfalfa - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (40, N'Việt Nam', N'Bình Dương', NULL, N'Quanh năm', N'Ớt hiểm vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (41, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Bầu xanh vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (42, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Mướp hương vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (43, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Dưa chuột baby Lâm Đồng', 1, 12, N'11-4', 1, 1, 0, 0, 0, 0, 80, NULL, N'Dưa chuột có thể trồng nhiều vụ/năm.'),
        (44, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Đậu bắp vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (45, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Củ cải trắng mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (45, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Củ cải trắng rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (46, N'Việt Nam', N'Bắc Giang; Tây Ninh', N'Giống/nhãn Nhật, trồng tại Việt Nam', N'Vụ chính', N'Khoai lang Nhật vụ Xuân - Bắc Giang', 2, 5, N'4-5', 0, 0, 0, 0, 0, 0, 100, NULL, N'Nguồn khuyến nông: trồng sau Tết, thu đầu tháng 5 âm lịch.'),
        (46, N'Việt Nam', N'Bắc Giang; Tây Ninh', N'Giống/nhãn Nhật, trồng tại Việt Nam', N'Vụ chính', N'Khoai lang Nhật vụ Đông - Bắc Giang', 8, 12, N'11-12', 0, 0, 0, 0, 0, 0, 100, NULL, N'Nguồn khuyến nông: trồng cuối 8-đầu 9, thu tháng 12 âm lịch.'),
        (46, N'Việt Nam', N'Bắc Giang; Tây Ninh', N'Giống/nhãn Nhật, trồng tại Việt Nam', N'Vụ tham khảo', N'Khoai lang tím Nhật vụ Đông Xuân - Tây Ninh', 12, 4, N'2-4', 0, 0, 0, 0, 0, 0, 40, NULL, N'Nguồn khuyến nông Tây Ninh; dùng làm tham khảo cho giống Nhật trồng VN.'),
        (47, N'Việt Nam', N'Tây Nguyên', N'Vùng, chưa rõ tỉnh', N'Vụ chính', N'Sắn Tây Nguyên', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Sắn thường thu sau mùa mưa/vào mùa khô.'),
        (48, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Gừng Lâm Đồng', 10, 2, N'11-1', 0, 0, 0, 0, 0, 0, 100, NULL, N'Gừng thường thu khi cây già/cuối năm đến đầu năm.'),
        (49, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Hành tây Đà Lạt mùa khô/mát', 12, 4, N'1-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Hành tây Đà Lạt thường thuận mùa mát.'),
        (50, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Nấm kim châm - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (51, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Nấm bào ngư - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (52, N'Trung Quốc', N'Hồ Bắc/Suizhou (tham khảo); Trung Quốc', N'Nấm hương khô nhập khẩu', N'Quanh năm', N'Nấm hương khô - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (53, N'Việt Nam', N'Hòa Bình', N'Nấm linh chi đỏ trồng tại Việt Nam', N'Quanh năm', N'Nấm linh chi đỏ - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (54, N'Việt Nam', N'Đồng Tháp', NULL, N'Quanh năm', N'Nấm rơm tươi - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (55, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Hành lá vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (56, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Ngò rí vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (57, N'Việt Nam', N'Đồng Nai', NULL, N'Quanh năm', N'Húng lủi vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (58, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Tía tô vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (59, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Rau răm vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (60, N'Việt Nam', N'TP.HCM', NULL, N'Quanh năm', N'Hành tỏi phi TP.HCM - hàng chế biến', 1, 12, N'Quanh năm', 1, 0, 0, 0, 0, 0, 50, NULL, N'Hàng chế biến, không nên gán mùa vụ nông sản tươi.'),
        (61, N'Nhật Bản', N'Aomori', NULL, N'Vụ chính', N'Táo Fuji Nhật vụ thu hoạch', 9, 12, N'10-11', 0, 0, 0, 0, 0, 0, 100, NULL, N'Aomori/Japan apple harvest season.'),
        (61, N'Nhật Bản', N'Aomori', NULL, N'Sau thu hoạch', N'Táo Fuji bảo quản/lưu kho', 1, 4, N'1-3', 0, 0, 0, 0, 0, 1, 30, NULL, N'Táo Fuji có khả năng bảo quản sau vụ thu hoạch.'),
        (62, N'Úc', N'Murray Valley; Riverina; Riverland', NULL, N'Vụ nhập khẩu', N'Cam Cara/Navel Úc', 6, 10, N'7-9', 0, 0, 0, 1, 0, 0, 100, NULL, N'Lịch citrus Australia tham khảo.'),
        (63, N'Mỹ', N'California', N'Coachella Valley; San Joaquin Valley', N'Vụ nhập khẩu', N'Nho California', 5, 1, N'7-11', 0, 0, 0, 1, 0, 0, 100, NULL, N'California table grapes thường có mùa từ cuối xuân đến đầu đông.'),
        (64, N'Việt Nam', N'Tiền Giang', N'Cái Bè - Hòa Lộc', N'Vụ chính', N'Xoài cát Hòa Lộc vụ thuận', 3, 5, N'4-5', 0, 0, 0, 0, 0, 0, 100, NULL, N'Mùa xoài chính miền Tây/Tiền Giang.'),
        (64, N'Việt Nam', N'Tiền Giang', N'Cái Bè - Hòa Lộc', N'Vụ phụ/rải vụ', N'Xoài cát Hòa Lộc rải vụ', 10, 12, N'11-12', 0, 0, 0, 0, 1, 0, 35, NULL, N'Nguồn Bộ Công Thương có nhắc mùa tăng thêm cuối năm.'),
        (65, N'Việt Nam', N'Long An', N'Vĩnh Hưng/Tân Trụ/Long Trì', N'Vụ chính', N'Dưa hấu Long An vụ Tết', 12, 2, N'1-2', 0, 0, 0, 0, 0, 0, 100, NULL, N'Dưa hấu Long An phục vụ thị trường Tết.'),
        (65, N'Việt Nam', N'Long An', N'Vĩnh Hưng/Tân Trụ/Long Trì', N'Vụ phụ', N'Dưa hấu Long An vụ hè', 4, 7, N'5-6', 0, 0, 0, 0, 1, 0, 35, NULL, N'Vụ hè tham khảo cho dưa hấu miền Nam.'),
        (66, N'Việt Nam', N'Đắk Lắk', NULL, N'Vụ chính', N'Bơ Đắk Lắk/Booth', 6, 11, N'8-10', 0, 0, 0, 0, 0, 0, 100, NULL, N'Bơ Đắk Lắk thường tập trung giữa năm đến cuối năm; Booth muộn hơn một số giống.'),
        (67, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt/Lạc Dương', N'Vụ chính', N'Dâu tây Đà Lạt mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Dâu tây Đà Lạt thuận mùa mát.'),
        (67, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt/Lạc Dương', N'Vụ phụ/nhà kính', N'Dâu tây Đà Lạt rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ/nhà kính tùy giống và trang trại.'),
        (68, N'Việt Nam', N'Ninh Thuận', N'Ninh Sơn', N'Quanh năm', N'Chuối già Nam Mỹ', 1, 12, N'Quanh năm', 1, 0, 0, 0, 0, 0, 50, NULL, N'Chuối trồng vùng nhiệt đới có thể thu quanh năm theo lứa.'),
        (69, N'Việt Nam', N'Bình Phước', NULL, N'Quanh năm', N'Đu đủ Bình Phước', 1, 12, N'Quanh năm', 1, 0, 0, 0, 0, 0, 50, NULL, N'Cổng thông tin Bình Phước ghi nhóm cây ăn trái có đu đủ thu gần quanh năm.'),
        (70, N'Việt Nam', N'Bình Thuận', N'Vùng chỉ dẫn địa lý thanh long', N'Vụ thuận', N'Thanh long Bình Thuận vụ thuận', 4, 9, N'5-8', 0, 0, 0, 0, 0, 0, 100, NULL, N'Thanh long Bình Thuận vụ thuận theo điều kiện tự nhiên.'),
        (70, N'Việt Nam', N'Bình Thuận', N'Vùng chỉ dẫn địa lý thanh long', N'Vụ nghịch', N'Thanh long Bình Thuận chong đèn/vụ nghịch', 10, 3, N'11-2', 0, 0, 0, 0, 1, 0, 35, NULL, N'Bình Thuận có sản xuất vụ nghịch bằng xử lý ra hoa/chong đèn.'),
        (71, N'Thái Lan', N'Chanthaburi; Rayong; Trat', N'Miền Đông Thái Lan', N'Vụ chính', N'Măng cụt Thái Lan miền Đông', 4, 7, N'5-6', 0, 0, 0, 0, 0, 0, 100, NULL, N'Chanthaburi/Rayong/Trat thường là vùng măng cụt chính.'),
        (71, N'Thái Lan', N'Chanthaburi; Rayong; Trat', N'Miền Đông Thái Lan', N'Vụ phụ/miền Nam', N'Măng cụt Thái Lan kéo dài/trái vụ', 8, 10, N'8-9', 0, 0, 0, 0, 1, 0, 35, NULL, N'Một số vùng miền Nam Thái Lan có thể kéo dài mùa.'),
        (72, N'Việt Nam', N'Tiền Giang', N'Cái Bè/Cai Lậy/Châu Thành/Tân Phước/TX Cai Lậy', N'Quanh năm/rải vụ', N'Mít Thái Tiền Giang', 1, 12, N'3-7; 10-12', 1, 1, 0, 0, 1, 0, 80, NULL, N'Mít Thái có thể rải vụ, vùng Tiền Giang thu nhiều đợt trong năm.'),
        (73, N'Mỹ', N'California', N'San Joaquin Valley', N'Vụ nhập khẩu', N'Lựu đỏ California', 8, 11, N'9-10', 0, 0, 0, 1, 0, 0, 100, NULL, N'California pomegranate season.'),
        (74, N'Nhật Bản', N'Ibaraki; Shizuoka', NULL, N'Vụ chính', N'Dưa lưới Nhật Ibaraki/Shizuoka', 5, 8, N'6-7', 0, 0, 0, 0, 0, 0, 100, NULL, N'Dưa lưới Nhật có mùa mạnh cuối xuân-hè, tùy vùng/nhà kính.'),
        (74, N'Nhật Bản', N'Ibaraki; Shizuoka', NULL, N'Nhà kính', N'Dưa lưới Nhật nhà kính', 9, 12, N'10-11', 0, 0, 1, 0, 0, 0, 45, NULL, N'Nhà kính có thể mở rộng mùa cung ứng.'),
        (75, N'Mỹ', N'California', NULL, N'Vụ nhập khẩu', N'Mận đỏ California', 5, 10, N'6-8', 0, 0, 0, 1, 0, 0, 100, NULL, N'California plum season.'),
        (76, N'Nam Phi', N'Western Cape', N'Ceres/Groenland/Wolseley-Tulbagh', N'Vụ nhập khẩu', N'Lê Nam Phi', 2, 8, N'3-6', 0, 0, 0, 1, 0, 0, 100, NULL, N'South Africa pear export/harvest season tham khảo.'),
        (77, N'New Zealand', N'Bay of Plenty', N'Te Puke/Katikati', N'Vụ nhập khẩu', N'Kiwi vàng New Zealand', 4, 11, N'5-9', 0, 0, 0, 1, 0, 0, 100, NULL, N'New Zealand kiwifruit harvest/export season, Bay of Plenty là vùng chính.'),
        (78, N'Thái Lan', N'Prachuap Khiri Khan', N'Pran Buri/Thap Sakae context', N'Quanh năm', N'Dứa MD2 Thái Lan', 1, 12, N'3-6; 10-12', 1, 1, 0, 0, 0, 0, 80, NULL, N'Dứa Thái có cung ứng quanh năm, Prachuap Khiri Khan là vùng tham khảo.'),
        (101, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Xà lách lô lô mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (101, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Xà lách lô lô rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (102, N'Việt Nam', N'Long An', NULL, N'Vụ chính', N'Cải bẹ xanh mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (102, N'Việt Nam', N'Long An', NULL, N'Vụ phụ', N'Cải bẹ xanh rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (103, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Rau diếp mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (103, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Rau diếp rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (104, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ chính', N'Bông cải xanh baby mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (104, N'Việt Nam', N'Lâm Đồng', NULL, N'Vụ phụ', N'Bông cải xanh baby rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (105, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Bông cải trắng mini mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (105, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Bông cải trắng mini rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (106, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Cà chua beef Lâm Đồng', 1, 12, N'11-4', 1, 1, 0, 0, 0, 0, 80, NULL, N'Cà chua Lâm Đồng có thể sản xuất quanh năm, thuận mùa mát.'),
        (107, N'Việt Nam', N'Đồng Tháp', NULL, N'Quanh năm', N'Bí đao vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (108, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Đậu que vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (109, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Su hào mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (109, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Su hào rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (110, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ chính', N'Củ cải đỏ mùa mát', 11, 4, N'12-3', 0, 0, 0, 0, 0, 0, 100, NULL, N'Rau/củ khí hậu mát vùng cao nguyên, thuận vụ Đông-Xuân.'),
        (110, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Vụ phụ', N'Củ cải đỏ rải vụ', 5, 10, N'6-8', 0, 0, 1, 0, 1, 0, 35, NULL, N'Có thể rải vụ tại Đà Lạt/Lâm Đồng hoặc vùng phù hợp.'),
        (111, N'Việt Nam', N'Lâm Đồng', NULL, N'Quanh năm', N'Nấm đùi gà tươi - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (112, N'Việt Nam', N'Lâm Đồng', N'Đà Lạt', N'Quanh năm', N'Nấm hương tươi - nuôi trồng/kiểm soát', 1, 12, N'Quanh năm', 1, 0, 1, 0, 0, 0, 50, NULL, N'Nấm/rau mầm phụ thuộc chu kỳ nuôi trồng, không phải mùa tự nhiên cố định.'),
        (113, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Ngò gai vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (114, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Rau húng vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.'),
        (115, N'Trung Quốc', N'Hebei; Shandong; Jiangsu', N'Vùng rau/leek tham khảo', N'Vụ tham khảo', N'Tỏi tây Trung Quốc mùa mát', 10, 4, N'11-3', 0, 0, 0, 0, 0, 0, 40, NULL, N'Tỏi tây là rau mùa mát; vùng Trung Quốc/tỉnh nhập khẩu cần xác minh.'),
        (116, N'Việt Nam', N'Tiền Giang', NULL, N'Quanh năm', N'Chuối già Việt Nam Tiền Giang', 1, 12, N'Quanh năm', 1, 0, 0, 0, 0, 0, 50, NULL, N'Chuối có thể thu quanh năm theo lứa ở vùng nhiệt đới.'),
        (117, N'Việt Nam', N'Long An', NULL, N'Quanh năm', N'Ổi xá lị Long An', 1, 12, N'3-6; 9-12', 1, 1, 0, 0, 0, 0, 80, NULL, N'Ổi có thể xử lý/rải vụ, thường có nhiều đợt trong năm.'),
        (118, N'Việt Nam', N'Long An', N'Vĩnh Hưng/Tân Trụ/Long Trì', N'Vụ chính', N'Dưa hấu mini Long An vụ Tết', 12, 2, N'1-2', 0, 0, 0, 0, 0, 0, 100, NULL, N'Dưa hấu Long An phục vụ Tết.'),
        (118, N'Việt Nam', N'Long An', N'Vĩnh Hưng/Tân Trụ/Long Trì', N'Vụ phụ', N'Dưa hấu mini Long An vụ hè', 4, 7, N'5-6', 0, 0, 0, 0, 1, 0, 35, NULL, N'Vụ hè tham khảo.'),
        (119, N'Việt Nam', N'Bình Thuận', N'Vùng chỉ dẫn địa lý thanh long', N'Vụ thuận', N'Thanh long ruột trắng Bình Thuận vụ thuận', 4, 9, N'5-8', 0, 0, 0, 0, 0, 0, 100, NULL, N'Thanh long Bình Thuận vụ thuận.'),
        (119, N'Việt Nam', N'Bình Thuận', N'Vùng chỉ dẫn địa lý thanh long', N'Vụ nghịch', N'Thanh long ruột trắng Bình Thuận vụ nghịch', 10, 3, N'11-2', 0, 0, 0, 0, 1, 0, 35, NULL, N'Sản xuất vụ nghịch bằng chong đèn/xử lý ra hoa.'),
        (120, N'Việt Nam', N'Đắk Lắk', N'Krông Pắc/Cư M''gar', N'Vụ chính', N'Sầu riêng Đắk Lắk/Ri6', 7, 10, N'8-9', 0, 0, 0, 0, 0, 0, 100, NULL, N'Sầu riêng Đắk Lắk thường thu tập trung giữa-cuối năm.'),
        (121, N'Việt Nam', N'Vĩnh Long', N'Mang Thít', N'Vụ chính', N'Khoai mỡ Vĩnh Long', 2, 8, N'7-8', 0, 0, 0, 0, 0, 0, 100, NULL, N'Nguồn khuyến nông: xuống giống sau Đông Xuân, thu sau khoảng 6 tháng.'),
        (122, N'Việt Nam', N'Long An', N'Suy từ dòng Rau muống ProductID 1 trong catalog', N'Quanh năm', N'Rau muống vùng nhiệt đới', 1, 12, N'5-10', 1, 1, 0, 0, 0, 0, 80, NULL, N'Rau nhiệt đới/rau ăn quả có thể trồng nhiều vụ trong năm, thuận khi đủ nước.')
    ) AS source
    (
        ProductID,
        Country,
        ProvinceRegion,
        AreaDetail,
        SeasonType,
        SeasonLabel,
        StartMonth,
        EndMonth,
        PeakMonths,
        IsYearRound,
        HasPeakSeason,
        IsControlledCultivation,
        IsImportedSeason,
        IsOffSeason,
        IsPostHarvestAvailability,
        SeasonScoreWeight,
        ConfidenceLevel,
        SourceNote
    )
),
ValidRows AS
(
    SELECT source.*
    FROM SourceRows AS source
    INNER JOIN dbo.Products AS product
        ON product.ProductID = source.ProductID
)
MERGE dbo.ProductSeasonality AS target
USING ValidRows AS source
ON target.ProductID = source.ProductID
AND target.SeasonLabel = source.SeasonLabel
AND target.StartMonth = source.StartMonth
AND target.EndMonth = source.EndMonth
WHEN MATCHED AND
(
    ISNULL(target.Country, N'') <> ISNULL(source.Country, N'')
    OR ISNULL(target.ProvinceRegion, N'') <> ISNULL(source.ProvinceRegion, N'')
    OR ISNULL(target.AreaDetail, N'') <> ISNULL(source.AreaDetail, N'')
    OR ISNULL(target.SeasonType, N'') <> ISNULL(source.SeasonType, N'')
    OR ISNULL(target.PeakMonths, N'') <> ISNULL(source.PeakMonths, N'')
    OR ISNULL(target.IsYearRound, 0) <> ISNULL(source.IsYearRound, 0)
    OR ISNULL(target.HasPeakSeason, 0) <> ISNULL(source.HasPeakSeason, 0)
    OR ISNULL(target.IsControlledCultivation, 0) <> ISNULL(source.IsControlledCultivation, 0)
    OR ISNULL(target.IsImportedSeason, 0) <> ISNULL(source.IsImportedSeason, 0)
    OR ISNULL(target.IsOffSeason, 0) <> ISNULL(source.IsOffSeason, 0)
    OR ISNULL(target.IsPostHarvestAvailability, 0) <> ISNULL(source.IsPostHarvestAvailability, 0)
    OR ISNULL(target.SeasonScoreWeight, 0) <> ISNULL(source.SeasonScoreWeight, 0)
    OR ISNULL(target.ConfidenceLevel, N'') <> ISNULL(source.ConfidenceLevel, N'')
    OR ISNULL(target.SourceNote, N'') <> ISNULL(source.SourceNote, N'')
)
THEN UPDATE SET
    Country = source.Country,
    ProvinceRegion = source.ProvinceRegion,
    AreaDetail = source.AreaDetail,
    SeasonType = source.SeasonType,
    PeakMonths = source.PeakMonths,
    IsYearRound = source.IsYearRound,
    HasPeakSeason = source.HasPeakSeason,
    IsControlledCultivation = source.IsControlledCultivation,
    IsImportedSeason = source.IsImportedSeason,
    IsOffSeason = source.IsOffSeason,
    IsPostHarvestAvailability = source.IsPostHarvestAvailability,
    SeasonScoreWeight = source.SeasonScoreWeight,
    ConfidenceLevel = source.ConfidenceLevel,
    SourceNote = source.SourceNote,
    UpdatedAt = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET
THEN INSERT
(
    ProductID,
    Country,
    ProvinceRegion,
    AreaDetail,
    SeasonType,
    SeasonLabel,
    StartMonth,
    EndMonth,
    PeakMonths,
    IsYearRound,
    HasPeakSeason,
    IsControlledCultivation,
    IsImportedSeason,
    IsOffSeason,
    IsPostHarvestAvailability,
    SeasonScoreWeight,
    ConfidenceLevel,
    SourceNote
)
VALUES
(
    source.ProductID,
    source.Country,
    source.ProvinceRegion,
    source.AreaDetail,
    source.SeasonType,
    source.SeasonLabel,
    source.StartMonth,
    source.EndMonth,
    source.PeakMonths,
    source.IsYearRound,
    source.HasPeakSeason,
    source.IsControlledCultivation,
    source.IsImportedSeason,
    source.IsOffSeason,
    source.IsPostHarvestAvailability,
    source.SeasonScoreWeight,
    source.ConfidenceLevel,
    source.SourceNote
);
GO

DECLARE @ExpectedRows int =
(
    SELECT COALESCE(SUM(expected.SeasonRows), 0)
    FROM
    (
        VALUES
        (1, 1),
        (2, 2),
        (3, 1),
        (4, 2),
        (5, 1),
        (6, 2),
        (7, 2),
        (8, 1),
        (9, 1),
        (10, 1),
        (11, 1),
        (12, 1),
        (13, 2),
        (14, 2),
        (15, 2),
        (16, 2),
        (17, 1),
        (18, 1),
        (19, 2),
        (20, 2),
        (21, 1),
        (22, 1),
        (23, 1),
        (24, 1),
        (25, 1),
        (26, 2),
        (27, 1),
        (28, 1),
        (29, 1),
        (30, 2),
        (31, 1),
        (32, 2),
        (33, 2),
        (34, 1),
        (35, 1),
        (36, 1),
        (37, 2),
        (38, 2),
        (39, 1),
        (40, 1),
        (41, 1),
        (42, 1),
        (43, 1),
        (44, 1),
        (45, 2),
        (46, 3),
        (47, 1),
        (48, 1),
        (49, 1),
        (50, 1),
        (51, 1),
        (52, 1),
        (53, 1),
        (54, 1),
        (55, 1),
        (56, 1),
        (57, 1),
        (58, 1),
        (59, 1),
        (60, 1),
        (61, 2),
        (62, 1),
        (63, 1),
        (64, 2),
        (65, 2),
        (66, 1),
        (67, 2),
        (68, 1),
        (69, 1),
        (70, 2),
        (71, 2),
        (72, 1),
        (73, 1),
        (74, 2),
        (75, 1),
        (76, 1),
        (77, 1),
        (78, 1),
        (101, 2),
        (102, 2),
        (103, 2),
        (104, 2),
        (105, 2),
        (106, 1),
        (107, 1),
        (108, 1),
        (109, 2),
        (110, 2),
        (111, 1),
        (112, 1),
        (113, 1),
        (114, 1),
        (115, 1),
        (116, 1),
        (117, 1),
        (118, 2),
        (119, 2),
        (120, 1),
        (121, 1),
        (122, 1)
    ) AS expected(ProductID, SeasonRows)
    INNER JOIN dbo.Products AS product
        ON product.ProductID = expected.ProductID
);
DECLARE @ActualRows int =
(
    SELECT COUNT(*)
    FROM dbo.ProductSeasonality
    WHERE ProductID IN (SELECT DISTINCT ProductID FROM dbo.Products)
);

IF @ActualRows < @ExpectedRows
BEGIN
    RAISERROR(N'ProductSeasonality seed thieu dong. Expected at least %d, actual %d.', 16, 1, @ExpectedRows, @ActualRows);
    RETURN;
END;
GO
