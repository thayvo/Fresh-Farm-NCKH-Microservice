/* FreshFarmCatalogDB local seed - 2026-03-30
   Purpose:
   - Broaden the public product pool across multiple sellers on local dev.
   - Make recommendation seller-diversity tuning visible at runtime.
   Notes:
   - Local-dev only.
   - Reassigns a small, fixed subset of products away from seller 4 so
     PrimarySellerId can surface sellers 2, 47, and 51 in public payloads.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    IF OBJECT_ID(N'dbo.SellerProducts', N'U') IS NULL
        THROW 57501, 'Missing dbo.SellerProducts.', 1;

    IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
        THROW 57502, 'Missing dbo.Products.', 1;

    IF OBJECT_ID(N'tempdb..#Assignments', N'U') IS NOT NULL
        DROP TABLE #Assignments;

    CREATE TABLE #Assignments
    (
        ProductID int NOT NULL PRIMARY KEY,
        TargetSellerID int NOT NULL
    );

    INSERT INTO #Assignments (ProductID, TargetSellerID)
    VALUES
        (1, 2), (2, 2), (3, 2), (4, 2), (5, 2), (6, 2),
        (7, 47), (8, 47), (9, 47), (10, 47), (11, 47), (12, 47),
        (13, 51), (14, 51), (15, 51), (16, 51), (17, 51), (18, 51);

    IF EXISTS
    (
        SELECT 1
        FROM #Assignments a
        LEFT JOIN dbo.Products p ON p.ProductID = a.ProductID
        WHERE p.ProductID IS NULL
    )
        THROW 57503, 'One or more ProductID values do not exist in dbo.Products.', 1;

    BEGIN TRAN;

    UPDATE sp
    SET
        sp.IsActive = 0,
        sp.UpdatedAt = GETUTCDATE()
    FROM dbo.SellerProducts sp
    INNER JOIN #Assignments a ON a.ProductID = sp.ProductID
    WHERE sp.SellerID = 4
      AND sp.IsActive = 1;

    UPDATE sp
    SET
        sp.IsActive = 1,
        sp.UpdatedAt = GETUTCDATE()
    FROM dbo.SellerProducts sp
    INNER JOIN #Assignments a
        ON a.ProductID = sp.ProductID
       AND a.TargetSellerID = sp.SellerID;

    INSERT INTO dbo.SellerProducts
    (
        SellerID,
        ProductID,
        IsActive,
        CreatedAt,
        UpdatedAt
    )
    SELECT
        a.TargetSellerID,
        a.ProductID,
        1,
        GETUTCDATE(),
        NULL
    FROM #Assignments a
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.SellerProducts sp
        WHERE sp.SellerID = a.TargetSellerID
          AND sp.ProductID = a.ProductID
    );

    COMMIT;

    SELECT
        a.TargetSellerID AS SellerID,
        COUNT(*) AS AssignedProducts
    FROM #Assignments a
    GROUP BY a.TargetSellerID
    ORDER BY a.TargetSellerID;

    SELECT
        sp.SellerID,
        COUNT(*) AS ActiveLinks
    FROM dbo.SellerProducts sp
    WHERE sp.IsActive = 1
    GROUP BY sp.SellerID
    ORDER BY sp.SellerID;

    DROP TABLE #Assignments;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    IF OBJECT_ID(N'tempdb..#Assignments', N'U') IS NOT NULL
        DROP TABLE #Assignments;
    THROW;
END CATCH;
