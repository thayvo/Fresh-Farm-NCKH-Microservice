SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.CategoryAttribute', N'U') IS NULL
BEGIN
    RAISERROR(N'CategoryAttribute chua ton tai. Hay apply script catalog-readiness delta truoc.', 16, 1);
    RETURN;
END;

IF OBJECT_ID(N'dbo.ProductAttributeValue', N'U') IS NULL
BEGIN
    RAISERROR(N'ProductAttributeValue chua ton tai. Hay apply script catalog-readiness delta truoc.', 16, 1);
    RETURN;
END;

;WITH CategorySource AS
(
    SELECT DISTINCT p.CategoryId
    FROM dbo.Products AS p
    WHERE p.CategoryId IS NOT NULL
),
DesiredAttributes AS
(
    SELECT
        source.CategoryId,
        attribute.AttributeKey,
        attribute.DisplayName,
        attribute.SortOrder,
        attribute.Placeholder
    FROM CategorySource AS source
    CROSS APPLY
    (
        VALUES
            (N'flavor_profile', N'Hương vị', 10, N'Ví dụ: ngọt, cay, thanh'),
            (N'texture_profile', N'Kết cấu', 20, N'Ví dụ: giòn, mềm, dày'),
            (N'usage_profile', N'Gợi ý dùng', 30, N'Ví dụ: salad, xào, nấu canh')
    ) AS attribute(AttributeKey, DisplayName, SortOrder, Placeholder)
)
MERGE dbo.CategoryAttribute AS target
USING DesiredAttributes AS source
ON target.CategoryId = source.CategoryId
AND target.AttributeKey = source.AttributeKey
WHEN MATCHED AND
(
    ISNULL(target.DisplayName, N'') <> ISNULL(source.DisplayName, N'')
    OR ISNULL(target.Placeholder, N'') <> ISNULL(source.Placeholder, N'')
    OR ISNULL(target.InputType, N'') <> N'text'
    OR ISNULL(target.IsRequired, 0) <> 0
    OR ISNULL(target.IsFacet, 0) <> 1
    OR ISNULL(target.SortOrder, 0) <> source.SortOrder
    OR ISNULL(target.IsActive, 0) <> 1
)
THEN
    UPDATE SET
        DisplayName = source.DisplayName,
        InputType = N'text',
        IsRequired = 0,
        IsFacet = 1,
        SortOrder = source.SortOrder,
        Placeholder = source.Placeholder,
        IsActive = 1,
        UpdatedAt = GETUTCDATE()
WHEN NOT MATCHED BY TARGET
THEN
    INSERT
    (
        CategoryId,
        AttributeKey,
        DisplayName,
        InputType,
        IsRequired,
        IsFacet,
        SortOrder,
        Placeholder,
        IsActive
    )
    VALUES
    (
        source.CategoryId,
        source.AttributeKey,
        source.DisplayName,
        N'text',
        0,
        1,
        source.SortOrder,
        source.Placeholder,
        1
    );

;WITH ProductSignals AS
(
    SELECT
        p.ProductId,
        p.CategoryId,
        SearchText = LOWER(CONCAT(
            ISNULL(p.ProductName, N''), N' ',
            ISNULL(p.ShortDescription, N''), N' ',
            ISNULL(p.LongDescription, N'')
        ))
    FROM dbo.Products AS p
),
DerivedValues AS
(
    SELECT
        signals.ProductId,
        signals.CategoryId,
        AttributeKey = N'flavor_profile',
        ValueText =
            CASE
                WHEN signals.SearchText LIKE N'%cay%' THEN N'Cay'
                WHEN signals.SearchText LIKE N'%ngọt dịu%' THEN N'Ngọt dịu'
                WHEN signals.SearchText LIKE N'%ngọt thanh%' THEN N'Ngọt thanh'
                WHEN signals.SearchText LIKE N'%ngọt nhẹ%' THEN N'Ngọt nhẹ'
                WHEN signals.SearchText LIKE N'%ngọt%' THEN N'Ngọt'
                WHEN signals.SearchText LIKE N'%thanh%' THEN N'Thanh'
                WHEN signals.SearchText LIKE N'%bùi%' THEN N'Bùi'
                ELSE N'Tự nhiên'
            END,
        NormalizedValue =
            CASE
                WHEN signals.SearchText LIKE N'%cay%' THEN N'cay'
                WHEN signals.SearchText LIKE N'%ngọt dịu%' THEN N'ngot_diu'
                WHEN signals.SearchText LIKE N'%ngọt thanh%' THEN N'ngot_thanh'
                WHEN signals.SearchText LIKE N'%ngọt nhẹ%' THEN N'ngot_nhe'
                WHEN signals.SearchText LIKE N'%ngọt%' THEN N'ngot'
                WHEN signals.SearchText LIKE N'%thanh%' THEN N'thanh'
                WHEN signals.SearchText LIKE N'%bùi%' THEN N'bui'
                ELSE N'tu_nhien'
            END
    FROM ProductSignals AS signals

    UNION ALL

    SELECT
        signals.ProductId,
        signals.CategoryId,
        AttributeKey = N'texture_profile',
        ValueText =
            CASE
                WHEN signals.SearchText LIKE N'%giòn%' THEN N'Giòn'
                WHEN signals.SearchText LIKE N'%thịt dày%' OR signals.SearchText LIKE N'% dày%' THEN N'Dày'
                WHEN signals.SearchText LIKE N'%mềm%' THEN N'Mềm'
                WHEN signals.SearchText LIKE N'%xốp%' THEN N'Xốp'
                ELSE N'Tươi'
            END,
        NormalizedValue =
            CASE
                WHEN signals.SearchText LIKE N'%giòn%' THEN N'gion'
                WHEN signals.SearchText LIKE N'%thịt dày%' OR signals.SearchText LIKE N'% dày%' THEN N'day'
                WHEN signals.SearchText LIKE N'%mềm%' THEN N'mem'
                WHEN signals.SearchText LIKE N'%xốp%' THEN N'xop'
                ELSE N'tuoi'
            END
    FROM ProductSignals AS signals

    UNION ALL

    SELECT
        signals.ProductId,
        signals.CategoryId,
        AttributeKey = N'usage_profile',
        ValueText =
            CASE
                WHEN signals.SearchText LIKE N'%salad%' OR signals.SearchText LIKE N'%ăn sống%' THEN N'Salad / ăn sống'
                WHEN signals.SearchText LIKE N'%xào%' AND (signals.SearchText LIKE N'%canh%' OR signals.SearchText LIKE N'%hầm%') THEN N'Xào / nấu canh'
                WHEN signals.SearchText LIKE N'%xào%' THEN N'Xào'
                WHEN signals.SearchText LIKE N'%canh%' OR signals.SearchText LIKE N'%hầm%' THEN N'Nấu canh'
                WHEN signals.SearchText LIKE N'%nướng%' THEN N'Nướng'
                ELSE N'Đa dụng'
            END,
        NormalizedValue =
            CASE
                WHEN signals.SearchText LIKE N'%salad%' OR signals.SearchText LIKE N'%ăn sống%' THEN N'salad_an_song'
                WHEN signals.SearchText LIKE N'%xào%' AND (signals.SearchText LIKE N'%canh%' OR signals.SearchText LIKE N'%hầm%') THEN N'xao_nau_canh'
                WHEN signals.SearchText LIKE N'%xào%' THEN N'xao'
                WHEN signals.SearchText LIKE N'%canh%' OR signals.SearchText LIKE N'%hầm%' THEN N'nau_canh'
                WHEN signals.SearchText LIKE N'%nướng%' THEN N'nuong'
                ELSE N'da_dung'
            END
    FROM ProductSignals AS signals
)
MERGE dbo.ProductAttributeValue AS target
USING
(
    SELECT
        derived.ProductId,
        categoryAttribute.CategoryAttributeId,
        derived.ValueText,
        derived.NormalizedValue
    FROM DerivedValues AS derived
    INNER JOIN dbo.CategoryAttribute AS categoryAttribute
        ON categoryAttribute.CategoryId = derived.CategoryId
       AND categoryAttribute.AttributeKey = derived.AttributeKey
       AND categoryAttribute.IsActive = 1
) AS source
ON target.ProductId = source.ProductId
AND target.CategoryAttributeId = source.CategoryAttributeId
WHEN MATCHED AND ISNULL(target.Source, N'manual') = N'derived_v1'
    AND (ISNULL(target.ValueText, N'') <> ISNULL(source.ValueText, N'')
      OR ISNULL(target.NormalizedValue, N'') <> ISNULL(source.NormalizedValue, N''))
THEN
    UPDATE SET
        ValueText = source.ValueText,
        NormalizedValue = source.NormalizedValue,
        UpdatedAt = GETUTCDATE()
WHEN NOT MATCHED BY TARGET
THEN
    INSERT
    (
        ProductId,
        CategoryAttributeId,
        ValueText,
        NormalizedValue,
        Source,
        CreatedAt
    )
    VALUES
    (
        source.ProductId,
        source.CategoryAttributeId,
        source.ValueText,
        source.NormalizedValue,
        N'derived_v1',
        GETUTCDATE()
    );
